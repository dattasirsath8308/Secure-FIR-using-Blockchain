package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserRegisterServlet
 */
@WebServlet("/UserRegisterServlet")
public class UserRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserRegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");

		PrintWriter out = response.getWriter();
		
		String UserName=request.getParameter("UserName");
		System.out.println(UserName);
		
		String Email=request.getParameter("Email");
		System.out.println(Email);
		
		String Address=request.getParameter("Address");
		System.out.println(Address);
		
		String Contact=request.getParameter("Contact");
		System.out.println(Contact);
		
		String Password=request.getParameter("Password");
		System.out.println(Password);
		
		
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			//Class.forName("com.mysql.jdbc.Driver");

		Connection con3 = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/crimerecord","root","root");

		// query to insert name and image name

		String query = "insert into userregister(UserName,Email,Address,Contact,Password) values (?,?,?,?,?)";

		PreparedStatement pst;
	//	id, StationName, Location, Admin, Landmark, email, Phone, question, answer, password, cpassword
		pst = (PreparedStatement) con3.prepareStatement(query);
			  pst.setString(1,UserName);
			  pst.setString(2,Email);
			  pst.setString(3,Address);
			  pst.setString(4,Contact);
		
			  pst.setString(5,Password);
			 
			 
			  
			  
			  
			 int i= pst.executeUpdate();
			 
			 if(i>0)
			 {
			  out.println("<script type=\"text/javascript\">");
			   out.println("alert('User register sucessfully..');");
			   out.println("location='UserLogin.jsp';");
			   out.println("</script>");
			 }
			 else
			 {
				 out.println("<script type=\"text/javascript\">");
				   out.println("alert('Not register..');");
				   out.println("location='UserRegister.jsp';");
				   out.println("</script>");
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
	     
		
	}

}
