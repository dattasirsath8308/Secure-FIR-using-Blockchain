package controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class UpdateNode
 */
@WebServlet("/UpdateNode")
public class UpdateNode extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		
		
		String id=request.getParameter("id");
		System.out.println(id);
		
		String statuss=request.getParameter("statuss");
		System.out.println(statuss);
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			 Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/crimerecord", "root", "root"); 
		   
		        String query = "update policeregister set  id=?,statuss=?  where id=?";

		        PreparedStatement pst;
		        pst = (PreparedStatement) con.prepareStatement(query);
		        pst.setString(1, id);
		        pst.setString(2, statuss);
		        pst.setString(3, id); 
		        int update= pst.executeUpdate();
		      
		        if(update>0)
		        {
		        	 out.println("<script type=\"text/javascript\">");
					   out.println("alert('update sucessfully..');");
					   out.println("location='AdminViewPoliceStation.jsp';");
					   out.println("</script>");
		        }
		        else
		        {
		        	 out.println("<script type=\"text/javascript\">");
					   out.println("alert('update not sucessfully..');");
					   out.println("location='AdminViewPoliceStation.jsp';");
					   out.println("</script>");
		        }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		        
	}

}
