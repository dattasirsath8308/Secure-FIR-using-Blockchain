package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dbconnect.Dataconnection;

/**
 * Servlet implementation class UpdatePass
 */
@WebServlet("/UpdatePass")
public class UpdatePass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();

		String Password=request.getParameter("password");

		System.out.println(Password);
		
		HttpSession s3=request.getSession();
		String Email=(String)s3.getAttribute("OTPMail");
		System.out.println(Email);
		
	
	

		try {
			Connection con2=Dataconnection.getConnection();
			String query="update userregister set Password=? where Email=?";
			PreparedStatement ps2=con2.prepareStatement(query);
			ps2.setString(1, Password);
		    ps2.setString(2, Email);
			
			int kk=ps2.executeUpdate();
			if(kk>0)
			{
				out.println("<script type=\"text/javascript\">");
				  out.println("alert('Password set Sucessfully..');");
				  out.println("location='UserLogin.jsp';");
				  out.println("</script>");
			}
			else
			{
				out.println("<script type=\"text/javascript\">");
				  out.println("alert('Incorrect details..');");
				  out.println("location='UpdatePass.jsp';");
				  out.println("</script>");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
			}

	}


