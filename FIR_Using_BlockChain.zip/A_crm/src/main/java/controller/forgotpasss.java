package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dbconnect.Dataconnection;
/**
 * Servlet implementation class forgotpasss
 */
@WebServlet("/forgotpasss")
public class forgotpasss extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String Email=request.getParameter("email");
		System.out.println(Email);
		
		String Sub="OPT for login";
		int length = 6;
		String Password=randomString.OTP(length);
		Mailer s=new Mailer();
		s.EmailSending(Email, Sub, Password);
		
		try {
			Connection con=Dataconnection.getConnection();
			String query="update userregister set Password=? where Email=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, Password);
			ps.setString(2, Email);
			int i=ps.executeUpdate();
			if(i>0)
			{
				HttpSession s2=request.getSession();
				s2.setAttribute("OTPMail", Email);
				System.out.println("Password update sucessfully");
				
				 out.println("<script type=\"text/javascript\">");
				  out.println("alert('Otp sent sucessfully..');");
				  out.println("location='EnterOtp.jsp';");
				  out.println("</script>");
			}
			
			else
			{
				 out.println("<script type=\"text/javascript\">");
				  out.println("alert('incorrect Email..');");
				  out.println("location='block.jsp';");
				  out.println("</script>");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	}


