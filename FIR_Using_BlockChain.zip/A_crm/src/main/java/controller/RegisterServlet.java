package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");

		PrintWriter out = response.getWriter();
		
		String StationName=request.getParameter("StationName");
		System.out.println(StationName);
		
		String Location=request.getParameter("Location");
		System.out.println(Location);
		
		String Admin=request.getParameter("Admin");
		System.out.println(Admin);
		
		String landmark=request.getParameter("landmark");
		System.out.println(landmark);
		
		String email=request.getParameter("email");
		System.out.println(email);
		
		String Phone=request.getParameter("Phone");
		System.out.println(Phone);
		
		String question=request.getParameter("question");
		System.out.println(question);
		
		String answer=request.getParameter("answer");
		System.out.println(answer);
		
		String password=request.getParameter("password");
		System.out.println(password);
		
		String cpassword=request.getParameter("cpassword");
		System.out.println(cpassword);
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			//Class.forName("com.mysql.jdbc.Driver");

		Connection con3 = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/crimerecord","root","root");

		// query to insert name and image name

		String query = "insert into policeregister(StationName,Location,Admin,Landmark,email,Phone,question,answer,password,cpassword) values (?,?,?,?,?,?,?,?,?,?)";

		PreparedStatement pst;
	//	id, StationName, Location, Admin, Landmark, email, Phone, question, answer, password, cpassword
		pst = (PreparedStatement) con3.prepareStatement(query);
			  pst.setString(1,StationName);
			  pst.setString(2,Location);
			  pst.setString(3,Admin);
			  pst.setString(4,landmark);
			  pst.setString(5,email);
			  pst.setString(6,Phone);
			  pst.setString(7,question);
			  pst.setString(8,answer);
			  pst.setString(9,password);
			  pst.setString(10,cpassword);
			 
			  
			  
			  
			 int i= pst.executeUpdate();
			 
			 if(i>0)
			 {
			  out.println("<script type=\"text/javascript\">");
			   out.println("alert('register sucessfully..');");
			   out.println("location='policelogin.jsp';");
			   out.println("</script>");
			 }
			 else
			 {
				 out.println("<script type=\"text/javascript\">");
				   out.println("alert('Not register..');");
				   out.println("location='policeregistration.jsp';");
				   out.println("</script>");
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
	     
	}

	}


