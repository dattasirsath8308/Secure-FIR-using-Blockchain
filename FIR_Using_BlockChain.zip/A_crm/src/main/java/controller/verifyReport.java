package controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import dbconnect.Dataconnection;


@WebServlet("/verifyReport")
public class verifyReport extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		/*HttpSession s2=request.getSession();
		String id=(String)s2.getAttribute("Riid");
		System.out.println("idd"+id);*/
		String id=request.getParameter("id");
		System.out.println("ifffff"+id);
		ArrayList<Integer>POW=new ArrayList<Integer>();
		ArrayList<Integer>POW1=new ArrayList<Integer>();
		try {
			Connection con=Dataconnection.getConnection();
			String qery="select * from requestsend where Rid='"+id+"'";
			PreparedStatement ps=con.prepareStatement(qery);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Integer PrevioushHash=rs.getInt(12);
				POW.add(PrevioushHash);
				
				Integer CurrentHash=rs.getInt(13);
				POW1.add(CurrentHash);
			}
			
			if(POW.equals(POW1))
			{
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('Block chain is Valid..');");
				   out.println("location='AdminVerifyReport.jsp';");
				   out.println("</script>");
			}
			else
			{
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('Block chain is Invalid..');");
				   out.println("location='AdminVerifyReport.jsp';");
				   out.println("</script>");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
