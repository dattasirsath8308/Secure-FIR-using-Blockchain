package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PoliceFirRegister
 */
@WebServlet("/PoliceFirRegister")
public class PoliceFirRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");

		PrintWriter out = response.getWriter();
		
		String fname=request.getParameter("vfname");
		System.out.println(fname);
		
		String lname=request.getParameter("vlname");
		System.out.println(lname);
		
		String dob=request.getParameter("dob");
		System.out.println(dob);
		
		String email=request.getParameter("email");
		System.out.println(email);
		
		String address=request.getParameter("address");
		System.out.println(address);
		
		String fir=request.getParameter("fir");
		System.out.println(fir);
		
		String place=request.getParameter("place");
		System.out.println(place);
		
		String policestationame=request.getParameter("policestationame");
		System.out.println(policestationame);
		
		
		
		
		 Date date = new Date();  
		    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");  
		    String currentDate = formatter.format(date);  
		    System.out.println("Date Format with MM/dd/yyyy : "+currentDate);
		
		    ArrayList<String>al=new ArrayList<>();
			al.add(request.getParameter("vfname"));
			
			al.add(request.getParameter("vlname"));
			al.add(request.getParameter("dob"));
			al.add(request.getParameter("email"));
			al.add(request.getParameter("address"));
			al.add(request.getParameter("fir"));
			al.add(request.getParameter("place"));
			al.add(request.getParameter("policestationame"));
			al.add(currentDate);
			
			System.out.println(al);
			
			
			String hash=al.toString();
			
			try {
				MessageDigest md=MessageDigest.getInstance("SHA-256");
				 byte[] hashInBytes = md.digest(hash.getBytes(StandardCharsets.UTF_8));
				 StringBuilder sb = new StringBuilder();
			     for (byte b : hashInBytes) {
			         sb.append(String.format("%02x", b));
			     }
			   String hashh=sb.toString();
		
		
	//	id, vfname, vlname, dob, email, address, fir, place, policestationame
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			//Class.forName("com.mysql.jdbc.Driver");

		Connection con3 = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/crimerecord","root","root");

		// query to insert name and image name

		String query = "insert into policeregisterfir(vfname, vlname, dob, email, address, fir, place, policestationame,currentDate,hashh) values (?,?,?,?,?,?,?,?,?,?)";

		PreparedStatement pst;

		pst = (PreparedStatement) con3.prepareStatement(query);
			  pst.setString(1,fname);
			  pst.setString(2,lname);
			  pst.setString(3,dob);
			  pst.setString(4,email);
			  pst.setString(5,address);
			  pst.setString(6,fir);
			  pst.setString(7,place);
			  pst.setString(8,policestationame);
			  pst.setString(9,currentDate);
			  pst.setString(10,hashh);
			 
			  
			 int i= pst.executeUpdate();
			 
			 if(i>0)
			 {
			  out.println("<script type=\"text/javascript\">");
			   out.println("alert('Fir register sucessfully..');");
			   out.println("location='policehome.jsp';");
			   out.println("</script>");
			 }
			 else
			 {
				 out.println("<script type=\"text/javascript\">");
				   out.println("alert('Fir Not register..');");
				   out.println("location='policehome.jsp';");
				   out.println("</script>");
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
	     
	}
			catch (NoSuchAlgorithmException e1) {
				
				e1.printStackTrace();
			}
	}
}

