package controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbconnect.Dataconnection;

/**
 * Servlet implementation class RequestSendToPolice
 */
@WebServlet("/RequestSendToPolice")
public class RequestSendToPolice extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");

		PrintWriter out = response.getWriter();
	/*	id, Rid, vfname, vlname, dob, email, address, fir, place, policestationame, currentDate, PreviousHash, CurrentHash, SenderEmail*/
		
		String Rid=request.getParameter("Rid");
		System.out.println(Rid);
		
		String vfname=request.getParameter("vfname");
		System.out.println(vfname);
		
		String vlname=request.getParameter("vlname");
		System.out.println(vlname);
		
		String dob=request.getParameter("dob");
		System.out.println(dob);
		
		String email=request.getParameter("email");
		System.out.println(email);
		
		String address=request.getParameter("address");
		System.out.println(address);
		
		String fir=request.getParameter("fir");
		System.out.println(fir);
		
		String place=request.getParameter("place");
		System.out.println(place);
		
		String policestationame=request.getParameter("policestationame");
		System.out.println(policestationame);
		
		String currentDate=request.getParameter("currentDate");
		System.out.println(currentDate);
		
		
		String SenderEmail=request.getParameter("SenderEmail");
		System.out.println(SenderEmail);
		
		String PreviousHash=request.getParameter("PreviousHash");
		System.out.println(PreviousHash);
		
		
			
		
		
		
		
		    ArrayList<String>al=new ArrayList<>();
			al.add(request.getParameter("vfname"));
			
			al.add(request.getParameter("vlname"));
			al.add(request.getParameter("dob"));
			al.add(request.getParameter("email"));
			al.add(request.getParameter("address"));
			al.add(request.getParameter("fir"));
			al.add(request.getParameter("place"));
			al.add(request.getParameter("policestationame"));
			al.add(currentDate);
			
			System.out.println(al);
		/*	String PreviousHash="oo";*/
			
			String hash=al.toString();
			
			try {
				MessageDigest md=MessageDigest.getInstance("SHA-256");
				 byte[] hashInBytes = md.digest(hash.getBytes(StandardCharsets.UTF_8));
				 StringBuilder sb = new StringBuilder();
			     for (byte b : hashInBytes) {
			         sb.append(String.format("%02x", b));
			     }
			   String CurrentHash=sb.toString();
		try {
			Connection con=Dataconnection.getConnection();
			String qry="insert into requestsend(Rid,vfname,vlname,dob,email,address,fir,place,policestationame,currentDate,PreviousHash,CurrentHash,SenderEmail) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(qry);
			pst.setString(1, Rid);
			pst.setString(2, vfname);
			pst.setString(3, vlname);
			pst.setString(4, dob);
			pst.setString(5, email);
			pst.setString(6, address);
			pst.setString(7, fir);
			pst.setString(8, place);
			pst.setString(9, policestationame);
			pst.setString(10, currentDate);
			pst.setString(11, PreviousHash);
			pst.setString(12, CurrentHash);
			pst.setString(13, SenderEmail);
			int i=pst.executeUpdate();
			if(i>0)
			{
				out.println("<script type=\"text/javascript\">");
				   out.println("alert('Data Send  sucessfully..');");
				   out.println("location='policehome.jsp';");
				   out.println("</script>");
			}
			else
			{
				out.println("<script type=\"text/javascript\">");
				   out.println("alert('Request Not Send  ..');");
				   out.println("location='PoliceRequestSend.jsp';");
				   out.println("</script>");
			}
			
				
		} catch (Exception e) {
			e.printStackTrace();
		}
		
			}catch (Exception e) {
				e.printStackTrace();
			}
			}
		
	}


