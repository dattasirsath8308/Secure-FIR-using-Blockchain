package dbconnect;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

//import com.sun.org.apache.bcel.internal.classfile.Field;

@SuppressWarnings("serial")
@WebServlet("/update")
@MultipartConfig
public class UploadFile extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
			
		Part p = req.getPart("files");
		String fileName = p.getSubmittedFileName();
//		String remark = req.getParameter("remark");
		
		HttpSession session = req.getSession();
	
		try {
			
			Connection conn = DBConnect.getConn();	
//			String sql = "insert into img_details(img_name,remark) values(?,?)";
			String sql = "insert into img_details(img_name) values(?)";

			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, fileName);
//			ps.setString(2, remark);
			
			int i = ps.executeUpdate();
			
			if(i==1) {
				
				String path =getServletContext().getRealPath("")+"img";
				System.out.println(path);
				
				File file=new File(path);
				p.write(path+file.separator+fileName);
				
				session.setAttribute("msg", "Upload Successfully");
				resp.sendRedirect("UserFirRegister.jsp");
//				System.out.println(path);
//				System.out.println("file Upload successfully..");
			}else {
				System.out.println("file Not Uploaded..");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
//		System.out.println(fileName +" filetype:- "+remark);
	}
	
}
