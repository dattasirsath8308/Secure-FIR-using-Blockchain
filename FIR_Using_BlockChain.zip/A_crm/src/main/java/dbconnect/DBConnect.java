package dbconnect;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnect {
	
	private static Connection conn;
	
	public static Connection getConn() {
		try {
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/crimerecord","root","root");
//				String sql = "insert into img_details(img_name,remark) values(?,?)";
				String sql = "insert into img_details(img_name) values(?)";
			
		} catch (Exception e) {
			e.printStackTrace();		}
		
		
		return conn;
	}
	
	
	
}
