package dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//import com.mysql.jdbc.PreparedStatement;
//import com.mysql.jdbc.ResultSet;

public class LoginDao {
	public static boolean validate(String email,String password,String statuss)
	{
		boolean status=false;
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Registered....");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crimerecord","root","root");
			System.out.println("Connection established....");
//			PreparedStatement pst=(PreparedStatement) conn.prepareStatement("select * from policeregister where email=? and password=? and statuss=? ");
			 PreparedStatement pst=(PreparedStatement) conn.prepareStatement("select * from policeregister where email=? and password=? and statuss=? ");
			
			
			pst.setString(1, email);
			pst.setString(2, password);
			pst.setString(3, statuss);
			ResultSet rs=(ResultSet) pst.executeQuery();
			status=rs.next();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		return status;
	}



}
